#include "Component.cpp"
#include "EventQueue.h"
#include "EventQueue.cpp"
#include "Event.c"
#include "config.h"
#include <time.h>

int ranged_rand(int, int);
void place_new_event(Component*);
void loop(EventQueue*, Component*,Component*,Component*);
//int find_next_up(EventQueue*);

int global_time;
int serial_stamp;

int main()
{
    /*  Dont bother seperating into a setup function.
        Setup consists entirely of setting variables, which would have to be
        declared and pass by location anyway. */
    
    // Create Event queue.
    EventQueue event_queue;
    
    // Create Components.
    Component cpu;
    Component disk_one;
    Component disk_two;
    
    // Set clock to zero.
    global_time = 0;
    
    // Seed random numbers.
    srand(time(NULL));
    
    // Create stamp to give events their serial numbers. Start is arbitrary.
    serial_stamp = 1000;
    
    // Setup Complete.
    
    loop(&event_queue, &cpu, &disk_one, &disk_two);
    
    
    return 0;
}

/*
 *  Main loop. Four major steps in each pass:
 *      Generate new CPU arrival.
 *      Find next job and advance time keeping.
 *      Handle event.
 *      Check if simulation over.
 */
 
 /*  Generally, I've tried to use member methods because I consider it easier to
    code without passing pointers to member objects. However, Object Oriented
    Scheduler class seemed more trouble than it was worth, so Scheduler does
    pass pointers to its own fields. */
 void loop(EventQueue* eq, Component* cpu, Component* disk_one, Component* disk_two)
 {
     // Generate CPU arrival
     place_new_event(cpu);
     
     // Find next job and advance time keeping.
     Event* next = eq->getNext();
     // Handle job.
     switch(next->jobtype){
         case JOB_ARRIVE_CPU:
            if(cpu->Getidle()){
                cpu->Setidle(false);
                // Calculate how long job will take.
                cpu->setTime(ranged_rand(CPU_MIN, CPU_MAX));
            } else {
                cpu->pushJob(next->serial);
                Event finish = *next;
                // TODO: Shedule event by putting completion in EQ. How to know completion time?
            }
            break;
        case JOB_CPU_D1:
            
            
     }
     
     return;
 }
 
/*
 *  Function creates new event and places in event queue.
 *  Takes pointer to cpu to allow insertion into queue.
 *  TODO: This is a bad way to distribute events. Can't I just fill the queue\
            during initialization, and then stop generating events?
 */
void place_new_event(Component* cpu)
{
    Event* ev = (Event*) malloc(sizeof(Event));
    // Give event next serial number available.
    ev->serial = serial_stamp++;
    // Record event as occuring
    ev->timestamp = global_time + ranged_rand(ARRIVAL_MIN, ARRIVAL_MAX);
    // Record job as a CPU arrival.
    ev->jobtype = JOB_ARRIVE_CPU;
    
}

/*
 *  Return random int in range [min,max).
 */
int ranged_rand(int min, int max)
{
    return (rand()%(max-min)) + min;
}